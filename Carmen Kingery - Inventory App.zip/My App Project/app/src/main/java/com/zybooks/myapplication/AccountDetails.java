package com.zybooks.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AccountDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_details);
    }
}